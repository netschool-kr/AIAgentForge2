# scripts/assign_admin_role.py
import os
import asyncio
from supabase import create_client, Client
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_SERVICE_KEY = os.getenv("SUPABASE_SERVICE_KEY")
USER_ID_TO_PROMOTE = "00000000-0000-0000-0000-000000000000"

async def assign_admin_role():
    if not all():
        print("오류: 필요한 환경 변수 또는 사용자 ID가 설정되지 않았습니다.")
        return
    print(f"'{USER_ID_TO_PROMOTE}' 사용자에게 'admin' 역할을 부여합니다...")

    supabase_admin: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)

    try:
        response = supabase_admin.auth.admin.update_user_by_id(
            USER_ID_TO_PROMOTE,
            {"app_metadata": {"role": "admin"}}
        )
        print("역할 부여 성공!")
        print("사용자 정보:", response.user.model_dump_json(indent=2))
    except Exception as e:
        print(f"오류 발생: {e}")

if __name__ == "__main__":
    asyncio.run(assign_admin_role())
