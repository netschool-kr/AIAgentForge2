import os
import resend
from dotenv import load_dotenv

# .env 파일에서 환경 변수를 로드합니다.
load_dotenv()

# 환경 변수에서 Resend API 키를 가져옵니다.
resend.api_key = os.environ.get("RESEND_API_KEY")
sender_email =os.environ.get("sender_email")
recipient_email =os.environ.get("recipient_email")
def send_test_email(from_email: str, to_email: str, subject: str, html_content: str):
    """
    Resend API를 사용하여 이메일을 보냅니다.

    Args:
        from_email (str): 보내는 사람의 이메일 주소.
        to_email (str): 받는 사람의 이메일 주소.
        subject (str): 이메일 제목.
        html_content (str): 이메일 본문 (HTML 형식).
    """
    if not resend.api_key:
        print("RESEND_API_KEY 환경 변수가 설정되지 않았습니다.")
        return

    try:
        # Resend에 이메일 전송 요청을 보냅니다.
        r = resend.Emails.send({
            "from": from_email,
            "to": [to_email],
            "subject": subject,
            "html": html_content,
        })
        print("이메일 전송 성공!")
        print(r)

    except Exception as e:
        print(f"이메일 전송 실패: {e}")

if __name__ == "__main__":
    # 이메일 전송 설정을 여기에 입력하세요.
    email_subject = "1 AIAgentForge 회원가입을 축하합니다!"
    email_body = """
    <h1>AIAgentForge 회원가입을 진심으로 환영합니다!</h1>
    <p>성공적으로 계정 생성이 완료되었습니다.</p>
    <p>이제 AI 에이전트와 함께 다양한 작업을 시작해 보세요.</p>
    <p>감사합니다.</p>
    """

    send_test_email(sender_email, recipient_email, email_subject, email_body)
