# AIAgentForge/scripts/get_token.py
import os
import json
from supabase import create_client, Client
from dotenv import load_dotenv

# .env 파일에서 환경 변수를 로드합니다.
load_dotenv()

# --- 설정 ---
# .env 파일에 다음 변수들이 정의되어 있어야 합니다:
# SUPABASE_URL, SUPABASE_ANON_KEY, TEST_USER_EMAIL, TEST_USER_PASSWORD
URL: str = os.environ.get("SUPABASE_URL")
KEY: str = os.environ.get("SUPABASE_ANON_KEY")
TEST_EMAIL: str = os.environ.get("TEST_USER_EMAIL")
TEST_PASSWORD: str = os.environ.get("TEST_USER_PASSWORD")
TOKEN_FILE = "session.json"

def get_and_save_token():
    """
    Supabase에 로그인하여 세션 정보를 가져오고,
    전체 세션 객체를 JSON 파일에 저장합니다.
    """

    if not all([URL, KEY, TEST_EMAIL, TEST_PASSWORD]):
        print("오류: 필요한 환경 변수가 .env 파일에 설정되지 않았습니다.")
        return

    try:
        # Supabase 클라이언트 생성
        supabase: Client = create_client(URL, KEY)
        
        # 이메일과 비밀번호로 로그인 시도
        response = supabase.auth.sign_in_with_password(
            {"email": TEST_EMAIL, "password": TEST_PASSWORD}
        )
        
        # 응답에 세션 정보가 있는지 확인
        if response.session:
            print("로그인 성공! 세션 정보를 저장합니다.")
            session_data = {
                "access_token": response.session.access_token,
                "refresh_token": response.session.refresh_token,
                "user_id": response.user.id,
                "expires_at": response.session.expires_at,
            }
            
            # 세션 데이터를 JSON 파일에 저장
            with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                json.dump(session_data, f, indent=4)
            print(f"토큰이 '{TOKEN_FILE}' 파일에 성공적으로 저장되었습니다.")
        else:
            print("로그인 실패: 응답에 세션 정보가 없습니다.")
            if response.user is None and response.session is None:
                print("이메일 또는 비밀번호가 잘못되었을 수 있습니다.")
    
    except Exception as e:
        print(f"오류 발생: {e}")

if __name__ == "__main__":
    get_and_save_token()