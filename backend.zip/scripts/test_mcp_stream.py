# AIAgentForge/scripts/test_mcp_stream.py
import os
import json
import requests
import sseclient
from dotenv import load_dotenv

#.env 파일에서 환경 변수를 로드합니다.
load_dotenv()

# --- 설정 ---
# 로컬 개발 서버의 기본 주소
BASE_URL = "http://localhost:8000"
TOKEN_FILE = "session.json"

def load_token_from_file():
    """
    'session.json' 파일에서 access_token을 읽어옵니다.
    파일이 없거나, 손상되었거나, 토큰이 없는 경우 예외를 발생시킵니다.
    """
    try:
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            session_data = json.load(f)
        
        access_token = session_data.get("access_token")
        if not access_token:
            raise KeyError("'access_token'을 파일에서 찾을 수 없습니다.")
        return access_token
    except FileNotFoundError:
        print(f"오류: '{TOKEN_FILE}' 파일을 찾을 수 없습니다.")
        print("먼저 'python get_token.py'를 실행하여 토큰을 생성하세요.")
        return None
    except (json.JSONDecodeError, KeyError) as e:
        print(f"오류: '{TOKEN_FILE}' 파일 처리 중 오류 발생: {e}")
        return None

def test_mcp_stream():
    """
    저장된 토큰을 사용하여 MCP 스트리밍 엔드포인트에 POST 요청을 보내고,
    수신되는 SSE 이벤트를 실시간으로 처리하여 출력합니다.
    """
    access_token = load_token_from_file()
    if not access_token:
        return

    # API 엔드포인트 URL
    url = f"{BASE_URL}/api/v1/mcp/stream"

    # 요청 헤더에 인증 토큰 포함
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "text/event-stream"
    }

    # 요청 본문(payload) 정의
    payload = {
        "query": "Reflex 프레임워크의 상태 관리는 어떻게 작동하나요?",
        # 테스트할 실제 collection_id로 변경해야 합니다.
        "collection_id": "YOUR_COLLECTION_ID_HERE", 
        "match_count": 5
    }

    print(f"'{url}'에 스트리밍 요청을 보냅니다...")
    print(f"Payload: {json.dumps(payload, indent=2, ensure_ascii=False)}\n")

    try:
        # stream=True 옵션으로 POST 요청을 시작합니다.
        response = requests.post(url, headers=headers, json=payload, stream=True)
        response.raise_for_status()  # 2xx 상태 코드가 아니면 예외 발생

        # sseclient-py를 사용하여 응답 객체를 래핑합니다.
        client = sseclient.SSEClient(response)

        # 이벤트를 실시간으로 순회하며 처리합니다.
        for event in client.events():
            print(f"--- 이벤트 수신 (type: {event.event}) ---")
            
            if not event.data:
                print("데이터 없음")
                continue

            try:
                # 데이터는 JSON 문자열이므로 파싱합니다.
                data = json.loads(event.data)
                
                if event.event == "search_started":
                    print(f"검색 시작됨. 쿼리: '{data.get('query')}'")
                elif event.event == "chunks_found":
                    print(f"{len(data)}개의 관련 문서 조각을 찾았습니다:")
                    for i, chunk in enumerate(data, 1):
                        print(f"  [{i}] Score: {chunk.get('rrf_score'):.4f} | Content: '{chunk.get('content', '')[:80]}...'")
                elif event.event == "stream_end":
                    print("스트림이 정상적으로 종료되었습니다.")
                    break
                elif event.event == "error":
                    print(f"서버 오류 발생: {data.get('detail')}")
                    break
                else: # 'message' 또는 정의되지 않은 이벤트 타입
                    print(f"수신된 데이터: {json.dumps(data, indent=2, ensure_ascii=False)}")

            except json.JSONDecodeError:
                print(f"JSON 파싱 오류. 원본 데이터: {event.data}")
            
            print("-" * (len(event.event) + 20) + "\n")

    except requests.exceptions.HTTPError as e:
        print(f"HTTP 오류 발생: {e.response.status_code} {e.response.reason}")
        if e.response.status_code == 401:
            print("인증 실패. 토큰이 만료되었거나 유효하지 않을 수 있습니다. 'python get_token.py'를 다시 실행하세요.")
        else:
            print(f"응답 내용: {e.response.text}")
    except requests.exceptions.RequestException as e:
        print(f"연결 오류 발생: {e}")
    except Exception as e:
        print(f"알 수 없는 오류 발생: {e}")

if __name__ == "__main__":
    test_mcp_stream()

